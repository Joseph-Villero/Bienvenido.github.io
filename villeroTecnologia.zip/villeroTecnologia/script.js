document.addEventListener('DOMContentLoaded', () => {
    const boton = document.getElementById('saludoBtn');
    
    boton.addEventListener('click', () => {
        alert('Hola Los archivos estan conectados correctamente.');
    });
});