# Proyecto de Estructura Web Basica

## Que es o para que sirve este repositorio?
Este repositorio sirve para demostrar la correcta separacion de archivos en un proyecto web y la implementacion de la estructura semantica minima (Header, Main y Footer). Contiene una pagina web estatica basica que funciona como prueba de concepto para la organizacion de codigo.

## Que tecnologias utilizaste?
* HTML: Para crear la estructura semantica de la pagina
* CSS: Para el estilo visual y la presentacion
* JavaScript: Para agregar interactividad basica a la pagina